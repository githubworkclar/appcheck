"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class DropDownModel {
    constructor(options = {}) {
        this.id = options.id;
        this.label = options.label;
        this.value = options.value;
    }
}
exports.DropDownModel = DropDownModel;
//# sourceMappingURL=dropdown.js.map