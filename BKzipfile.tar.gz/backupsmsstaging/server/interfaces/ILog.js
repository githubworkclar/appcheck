"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=ILog.js.map