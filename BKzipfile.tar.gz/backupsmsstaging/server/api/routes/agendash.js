"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = (app) => {
    //   const agendaInstance = Container.get('agendaInstance')
    //   app.use('/dash', 
    //     basicAuth({
    // 	  users: {
    // 	    [config.agendash.user]: config.agendash.password,
    // 	  },
    // 	  challenge: true,
    // 	}),
    // 	agendash(agendaInstance)
    //   )
};
//# sourceMappingURL=agendash.js.map