"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    user: {
        signUp: 'onUserSignUp',
        signIn: 'onUserSignIn',
    },
};
//# sourceMappingURL=events.js.map