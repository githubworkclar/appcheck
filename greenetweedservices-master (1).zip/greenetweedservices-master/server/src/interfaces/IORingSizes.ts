export interface IORingSizes {
  dashSize: number;
  oringCrossSectionSize: number;
  oringDiameterSize: number;
  glandIdSize: number;
  glandIdTolerance: number;
}