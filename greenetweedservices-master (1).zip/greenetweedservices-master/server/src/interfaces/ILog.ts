export interface ILog {
  message: string;
  level: number;
}

export interface ILogInputDTO {
  message: string;
  level: number;
}
