export interface IPerson {
  _id: string;
  fname: string;
  lname: string;
}

export interface IPesronInputDTO {
  name: string;
  email: string;
  password: string;
}
