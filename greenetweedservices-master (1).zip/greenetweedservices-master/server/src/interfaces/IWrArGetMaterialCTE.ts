export interface IWrArGetMaterialCTE {
    unit: string;
    material: any;
}