export interface IWrArCalculatedIntereference {
  TargetValue?: number,
  Standard?: number,
  Max?: number,
  Min?: number
}