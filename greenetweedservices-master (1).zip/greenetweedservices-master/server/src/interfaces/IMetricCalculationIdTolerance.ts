export interface IMetricCalculationIdTolerance {
  _id: String;
  crossSectionMin: Number;
  crossSectionMax: Number;
  diameterMin: Number;
  diameterMax: Number;
  diameterTolerance: Number;
}