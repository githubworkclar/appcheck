export interface IWrArMaterial {
    _id: any;
    materialName: string;
    poissonsRatio: Number;
    modulusPSI: Number;
    rotorCTE: Number;
    statorCTE: Number;
}