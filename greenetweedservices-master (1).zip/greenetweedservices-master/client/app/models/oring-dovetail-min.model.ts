export class MinValue {
  glandWidthMin: number;
  glandDepthMin: number;
  glandAngleMin: number;
  bottomRadiiMin: number;
  topRadiiMin: number;
  gapMin: number;
  glandCenterlineMin: number;
}