export class RadiiRecomendationNominal {
    h: number = 0;
    w: number = 0;
    bottomRadiiPercent: number = 0;
    topRadiiPercent: number = 0;
  }