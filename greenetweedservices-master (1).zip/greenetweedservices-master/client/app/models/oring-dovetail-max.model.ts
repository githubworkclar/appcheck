export class MaxValue {
    glandWidthMax: number;
    glandDepthMax: number;
    glandAngleMax: number;
    bottomRadiiMax: number;
    topRadiiMax: number;
    gapMax: number;
    glandCenterlineMax: number;
  }