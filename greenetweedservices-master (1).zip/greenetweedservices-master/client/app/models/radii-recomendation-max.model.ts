export class RadiiRecomendationMax {
    hMax: number;
    wMax: number;
    bottomRadiiMaxPercent: number;
    topRadiiMaxPercent: number;

    constructor() {
        this.hMax = 0;
        this.wMax = 0;
        this.bottomRadiiMaxPercent = 0;
        this.topRadiiMaxPercent = 0;
      }
}