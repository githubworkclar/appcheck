export interface IBottomRadiiWarningRanges {
    bottomRadiiWarningMinRange1: number,
    bottomRadiiWarningMaxRange1: number,
    bottomRadiiWarningMinRange2: number,
    bottomRadiiWarningMaxRange2: number
  }