export const environment = {
  production: true,
  name: 'prod'
};
