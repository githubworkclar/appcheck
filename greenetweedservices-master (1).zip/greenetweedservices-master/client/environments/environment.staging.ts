export const environment = {
  production: true,
  name: 'staging'
};
